#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcaddon,xbmcplugin,xbmcgui,urllib,sys,re,os,xbmcvfs

try:
    #py2
    import urlparse
except:
    #py3
    import urllib.parse as urlparse
import os


addon = xbmcaddon.Addon()
pluginhandle = int(sys.argv[1])
addonID = addon.getAddonInfo('id')
icon1=xbmcvfs.translatePath('special://home/addons/'+addonID+'/xstream.png')
icon2=xbmcvfs.translatePath('special://home/addons/'+addonID+'/doku.png')
icon3=xbmcvfs.translatePath('special://home/addons/'+addonID+'/sradio.png')
icon5=xbmcvfs.translatePath('special://home/addons/'+addonID+'/music.png')
icon6=xbmcvfs.translatePath('special://home/addons/'+addonID+'/you.png')
icon7=xbmcvfs.translatePath('special://home/addons/'+addonID+'/rtlplus.png')
icon8=xbmcvfs.translatePath('special://home/addons/'+addonID+'/stube.png')
icon9=xbmcvfs.translatePath('special://home/addons/'+addonID+'/legsound.png')
icon10=xbmcvfs.translatePath('special://home/addons/'+addonID+'/disney.png')
icon11=xbmcvfs.translatePath('special://home/addons/'+addonID+'/vavoovod.png')
icon12=xbmcvfs.translatePath('special://home/addons/'+addonID+'/macvod.png')
icon13=xbmcvfs.translatePath('special://home/addons/'+addonID+'/joyn.png')
icon14=xbmcvfs.translatePath('special://home/addons/'+addonID+'/xship.png')
icon15=xbmcvfs.translatePath('special://home/addons/'+addonID+'/mediathek.jpg')
fanartlegsound=xbmcvfs.translatePath('special://home/addons/'+addonID+'/fanartlegsound.jpg')
fanartxship=xbmcvfs.translatePath('special://home/addons/'+addonID+'/fanartxship.jpg')
fanartxstream=xbmcvfs.translatePath('special://home/addons/'+addonID+'/fanartxstream.jpg')
fanartdisney=xbmcvfs.translatePath('special://home/addons/'+addonID+'/fanartdisney.jpg')
fanartdoku=xbmcvfs.translatePath('special://home/addons/'+addonID+'/fanartdoku.jpg')
fanartmusic=xbmcvfs.translatePath('special://home/addons/'+addonID+'/fanartmusic.png')
fanartyou=xbmcvfs.translatePath('special://home/addons/'+addonID+'/fanartyou.jpeg')
fanartrtl=xbmcvfs.translatePath('special://home/addons/'+addonID+'/fanartrtl.jpg')
fanartsradio=xbmcvfs.translatePath('special://home/addons/'+addonID+'/fanartsradio.jpg')
fanartvavoo=xbmcvfs.translatePath('special://home/addons/'+addonID+'/fanartvavoo.jpg')
fanartmacsimum=xbmcvfs.translatePath('special://home/addons/'+addonID+'/fanartmacsimum.jpg') 
fanartjoyn=xbmcvfs.translatePath('special://home/addons/'+addonID+'/fanartjoyn.jpg')
fanartmediathek=xbmcvfs.translatePath('special://home/addons/'+addonID+'/fanartmediathek.png')


addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path')
icon_path = os.path.join(addon_path,'resources','icon')
xbmcplugin.setContent(handle=int(sys.argv[1]), content='files')
				
def add_item(name, url, iconimage='', fanart='', isFolder=True, IsPlayable=False):
    urlParams = {'name': name, 'url': url, 'iconimage': iconimage}
    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': iconimage, 'thumb': iconimage, 'fanart': fanart})
    liz.setInfo('video', {'title': name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=liz, isFolder=isFolder)
    return ok


def index():
    add_item("x.STREAM", "plugin://plugin.video.xstream", icon1, fanartxstream)
    add_item("x.SHIP", "plugin://plugin.video.xship", icon14, fanartxship)
    add_item("MAC:simum", "plugin://plugin.video.stalker.macsimum", icon12, fanartmacsimum)
    add_item("VAVOO","plugin://plugin.video.vavooto",icon11, fanartvavoo)
    add_item("RTL+","plugin://plugin.video.tvnow.de",icon7, fanartrtl)
    add_item("Disney+", "plugin://slyguy.disney.plus", icon10, fanartdisney)
    add_item("joyn","plugin://plugin.video.joyn",icon13, fanartjoyn)
    add_item("MEDIATHEK","plugin://plugin.video.mediathekviewweb",icon15, fanartmediathek)
    add_item("MICLIER.DOKU","plugin://plugin.video.miclier-doku?sf_options=fanart%3Dspecial%3A%2F%2Fhome%2Faddons%2Fplugin.video.miclier-doku%2Fresources%2Ffanart.jpg%26meta%3Dlabel%253D%25255BCOLORgreen%25255DMICLIER%25255B%25252FCOLOR%25255D-DOKU%26desc%3DDoku+Kan%C3%A4le+auf+Youtube+Terra+X%2CZDF+Histroy%2CArte%2CN24+usw+.%26_options_sf",icon2, fanartdoku)
    add_item("ALL.KINDS.OF.MUSIC","plugin://plugin.video.All.Kinds.of.Music",icon5, fanartmusic)
    add_item("LEGACY.SOUNDS","plugin://plugin.video.legacy.sounds",icon9, fanartlegsound)
    add_item("RADIO.STUBE","plugin://plugin.audio.radiostube",icon3, fanartsradio)
    add_item("YOU.TUBE","plugin://plugin.video.youtube",icon6, fanartyou)

   

    xbmcplugin.endOfDirectory(pluginhandle)
def translation(id):
    return addon.getLocalizedString(id).encode('utf-8')

def parameters_string_to_dict(parameters):
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

index()